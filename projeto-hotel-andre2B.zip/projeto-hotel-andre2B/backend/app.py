import os
from flask import Flask, send_from_directory


BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__),",,"))

FRONTEND_DIR = os.path.join(BASE_DIR, "frontend")

STATIC_DIR = os.path.join(BASE_DIR, "static")

app = Flask(__name__, static_folder=STATIC_DIR,static_url_path="/")

@app.route("/")
def home():
    return "Bom dia galera 2B"
    
    
app.run()